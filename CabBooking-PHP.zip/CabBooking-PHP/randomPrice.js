// randomPrice.js

function getRandomPrice() {
    // Generate a random price between 400 and 1500
    return Math.floor(Math.random() * (1500 - 400 + 1)) + 400;
}

// Update the price-display div with the random price
function updatePriceDisplay() {
    const priceDisplay = document.getElementById('random-price');
    if (priceDisplay) {
        const randomPrice = getRandomPrice();
        priceDisplay.textContent = `$${randomPrice}`;
    }
}

// Call the updatePriceDisplay function when the page loads
document.addEventListener('DOMContentLoaded', () => {
    updatePriceDisplay();
});
